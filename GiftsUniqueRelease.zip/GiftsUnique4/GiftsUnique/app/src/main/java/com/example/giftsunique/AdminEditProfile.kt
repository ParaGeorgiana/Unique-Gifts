package com.example.giftsunique

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class AdminEditProfile : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()

        setContentView(R.layout.edit_profile_administrator)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        val fullName = findViewById<TextInputLayout>(R.id.editfullName)
        val phoneNumber = findViewById<TextInputLayout>(R.id.editphoneNumber)
        val saveData = findViewById<Button>(R.id.editData)
        saveData.setOnClickListener {
            val editFullName = fullName.editText?.text.toString()
            val editPhoneNumber = phoneNumber.editText?.text.toString()
            if (editFullName.isEmpty()) {
                fullName.error = "Introdu numele tau"
                Toast.makeText(this, "Introdu numele tau", Toast.LENGTH_SHORT).show()
            }
            else {
                if (editPhoneNumber.length != 10) {
                    phoneNumber.error = "Numarul de telefon trebuia sa aiba 10 cifre"
                    Toast.makeText(this, "Numarul de telefon trebuia sa aiba 10 cifre", Toast.LENGTH_SHORT).show()
                }
                else{
                    val userReference =
                        database.reference.child("Users").child(auth.currentUser!!.uid)
                    val updates = HashMap<String, Any>()
                    updates["fullName"] = editFullName
                    updates["phoneNumber"] = editPhoneNumber
                    userReference.updateChildren(updates)
                    Toast.makeText(this, "Datele au fost actualizate cu succes", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, AdminMain::class.java)
                    intent.putExtra("phoneNumber", editPhoneNumber)
                    intent.putExtra("fullName", editFullName)
                    startActivity(intent)
                }}
        }
    }
}