package com.example.giftsunique
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.view.Window
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.view.WindowManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ClientMain:AppCompatActivity() {
    private lateinit var title: TextView
    private lateinit var needgift: LinearLayout
    private lateinit var database: DatabaseReference
    private lateinit var adapter: ClientOrderAdapter
    private lateinit var auth: FirebaseAuth
    private lateinit var orderRecyclerView: RecyclerView
    private lateinit var orderList: ArrayList<Order>
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()

        setContentView(R.layout.client_homepage)
        title = findViewById(R.id.clientfullname)

        if(intent.getStringExtra("fullName") != null) {
            title.text = "Bine ai venit, " + intent.getStringExtra("fullName") + "!"
        }else {
            title.text = ""
        }
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        val settingsButton = findViewById<ImageView>(R.id.settingsClient)
        settingsButton.setOnClickListener{
            val intent = Intent(this, ClientEditProfile::class.java)
            startActivity(intent)
        }
        val orderHistoryButton = findViewById<ImageView>(R.id.ordersHistory)
        orderHistoryButton.setOnClickListener{
            val intent = Intent(this, ClientHistory::class.java)
            startActivity(intent)
        }
        val needgiftButton=findViewById<ImageView>(R.id.needgift)
        needgiftButton.setOnClickListener{
            val intent = Intent(this, GiveOrder::class.java)
            startActivity(intent)
        }
        val startShoppingButton=findViewById<ImageView>(R.id.startShopping)
        startShoppingButton.setOnClickListener{
            val intent = Intent(this, MainFragment::class.java)
            startActivity(intent)
        }
        orderList = ArrayList()
        adapter = ClientOrderAdapter(this, orderList)
        orderRecyclerView = findViewById(R.id.orderRecyclerView)
        orderRecyclerView.layoutManager = LinearLayoutManager(this)
        orderRecyclerView.adapter = adapter

        database.child("Order").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                orderList.clear()
                for (postSnapshot in snapshot.children) {
                    val order = postSnapshot.getValue(Order::class.java)
                    if (order != null) {
                        if ((auth.currentUser?.uid == order.clientUID) &&
                            (order.accepted == true) && (order.active == true)
                        ) {
                            orderList.add(order)
                        }
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
            }

        })

    }
}