object SingletonPhone {
    private var id: String = "" // ID variable

    fun getId(): String {
        return id
    }

    fun setId(id: String) {
        this.id = id
    }

}