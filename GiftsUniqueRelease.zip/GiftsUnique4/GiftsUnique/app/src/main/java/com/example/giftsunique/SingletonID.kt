object SingletonID {
    private var id: String = ""

    fun getId(): String {
        return id
    }

    fun setId(id: String) {
        this.id = id
    }
}