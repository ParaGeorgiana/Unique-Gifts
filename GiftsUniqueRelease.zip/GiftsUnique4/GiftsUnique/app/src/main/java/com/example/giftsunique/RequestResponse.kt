package com.example.giftsunique

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Window

import android.widget.*
import androidx.appcompat.app.AppCompatActivity

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

import android.view.WindowManager

import com.google.firebase.database.*

class RequestResponse:  AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    private lateinit var accept: LinearLayout
    private lateinit var decline: LinearLayout
    private lateinit var back: ImageView
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().reference

        setContentView(R.layout.request_response)

        findViewById<ImageView>(R.id.BackButton).setOnClickListener {
            val intent = Intent(this, AdminMain::class.java)
            startActivity(intent)
        }
        findViewById<TextView>(R.id.requestclientName).text = intent.getStringExtra("fullName")
        findViewById<TextView>(R.id.clientWords).text = intent.getStringExtra("order")
        findViewById<TextView>(R.id.clientPhoneData).text = intent.getStringExtra("phoneNumber")
        findViewById<TextView>(R.id.clientSizeData).text = intent.getStringExtra("size")
        findViewById<TextView>(R.id.clientPriceData).text = intent.getStringExtra("price")
        val orderUid = intent.getStringExtra("uid").toString()
        accept = findViewById(R.id.layoutAcceptRequest)
        accept.setOnClickListener {
            val preparetime = findViewById<EditText>(R.id.givenpreparetime).text.toString()
            val orderStatus = findViewById<EditText>(R.id.givenorderStatus).text.toString()
            if (preparetime.isEmpty() || orderStatus.isEmpty()) {
                Toast.makeText(this, "Please don't leave the fields empty!", Toast.LENGTH_SHORT)
                    .show()
            }   else {
                val userReference =
                    orderUid?.let { it1 -> database.child("Order").child(it1) }
                val updates = HashMap<String, Any>()
                updates["preparetime"] = preparetime
                updates["orderStatus"] = orderStatus
                updates["adminUID"] = auth.currentUser?.uid.toString()
                updates["accepted"] = true
                userReference?.updateChildren(updates)
                val intent = Intent(this, AdminMain::class.java)
                startActivity(intent)
                Toast.makeText(this, "Comanda Acceptata", Toast.LENGTH_SHORT).show()
            }
        }
        decline=findViewById(R.id.layoutDeclineRequest)
        decline.setOnClickListener {
            val userReference =
                orderUid?.let { it1 -> database.child("Order").child(it1) }
            val updates = HashMap<String, Any>()
            updates["active"] = false
            userReference?.updateChildren(updates)
            val intent = Intent(this, AdminMain::class.java)
            startActivity(intent)
            Toast.makeText(this, "Comanda refuzata", Toast.LENGTH_SHORT).show()
        }

    }
}