package com.example.giftsunique

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import android.view.Window
import android.view.WindowManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
class AdminHistoryOrder : AppCompatActivity() {

    private lateinit var orderRecyclerView: RecyclerView
    private lateinit var orderList: ArrayList<Order>
    private lateinit var adapter: AdminHistoryOrderAdapter
    private lateinit var mDbRef: DatabaseReference
    private lateinit var mAuth: FirebaseAuth
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    private lateinit var back: ImageView

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()

        setContentView(R.layout.admin_orders_history)

        back = findViewById(R.id.backButton)
        back.setOnClickListener {
            val intent = Intent(this, AdminMain::class.java)
            startActivity(intent)
        }

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        mDbRef = FirebaseDatabase.getInstance().reference
        mAuth = FirebaseAuth.getInstance()
        orderList = ArrayList()
        adapter = AdminHistoryOrderAdapter(this, orderList)
        orderRecyclerView = findViewById(R.id.historyOrderRecyclerView)
        orderRecyclerView.layoutManager = LinearLayoutManager(this)
        orderRecyclerView.adapter = adapter
        mDbRef.child("Order").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                orderList.clear()
                for (postSnapshot in snapshot.children) {
                    val order = postSnapshot.getValue(Order::class.java)
                    if (order != null) {
                        if (
                            (order.accepted == true) && (order.active == false)
                        ) {
                            orderList.add(order)
                        }
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })
    }
}