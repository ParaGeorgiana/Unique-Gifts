package com.example.giftsunique

class ClientHistoryAdapter {
}