package com.example.giftsunique

data class Order(
    var uid: String? = null,
    var adminUID: String? = null,
    var clientUID: String? = null,
    var order: String? = null,
    var phoneNumber: String? = null,
    var preparetime: String? = null,
    var orderStatus: String? = null,
    var accepted: Boolean? = null,
    var active: Boolean? = null,
    val pid: String? = null,
    val imageUrl: String? = null,
    val name: String? = null,
    val size: String? = null,
    val price: String? = null
)