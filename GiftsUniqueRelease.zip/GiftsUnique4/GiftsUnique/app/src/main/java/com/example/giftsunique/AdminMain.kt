package com.example.giftsunique
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import android.view.Window
import android.view.WindowManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AdminMain:AppCompatActivity() {
    private lateinit var title: TextView
    private lateinit var back: ImageView
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var userRecyclerView: RecyclerView
    private lateinit var orderList: ArrayList<Order>
    private lateinit var adapter: AdminOrderAdapter
    private lateinit var mDbRef: DatabaseReference
    private lateinit var mAuth: FirebaseAuth
    private lateinit var pendingorders: LinearLayout
    private lateinit var historyorders: LinearLayout
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
        setContentView(R.layout.admin_homepage)
        title = findViewById(R.id.adminfullname)

        if (intent.getStringExtra("fullName") != null) {
            title.text = "Bine ai venit, " + intent.getStringExtra("fullName") + "!"
        } else {
            title.text = ""
        }
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        pendingorders = findViewById(R.id.layoutPendingOrders)
        pendingorders.setOnClickListener {
            val userRef =
                auth.currentUser?.let { it1 -> database.reference.child("Users/").child(it1.uid) }
            userRef?.get()?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val snapshot = task.result
                    val intent = Intent(this, OrderList::class.java)
                    startActivity(intent)
                }

            }

        }
        historyorders=findViewById(R.id.layoutclientsHistory)
        historyorders.setOnClickListener {
            val intent = Intent(this, AdminHistoryOrder::class.java)
            startActivity(intent)
        }
        val settingsButton = findViewById<ImageView>(R.id.settingsadmin)

        settingsButton.setOnClickListener{
            val intent = Intent(this, AdminEditProfile::class.java)
            startActivity(intent)
        }
        mDbRef = FirebaseDatabase.getInstance().reference
        mAuth = FirebaseAuth.getInstance()
        orderList = ArrayList()
        adapter = AdminOrderAdapter(this, orderList)
        userRecyclerView = findViewById(R.id.orderRecyclerView)
        userRecyclerView.layoutManager = LinearLayoutManager(this)
        userRecyclerView.adapter = adapter

        mDbRef.child("Order").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                orderList.clear()
                for (postSnapshot in snapshot.children) {
                    val order = postSnapshot.getValue(Order::class.java)
                    if (order != null) {
                        order.adminUID=auth.currentUser?.uid.toString()
                    }
                    if (order != null) {
                        if (mAuth.currentUser?.uid == order.adminUID &&(order.accepted == true) && (order.active == true)
                        ) {
                            orderList.add(order)
                        }
                    }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
            }
        })
    }
}