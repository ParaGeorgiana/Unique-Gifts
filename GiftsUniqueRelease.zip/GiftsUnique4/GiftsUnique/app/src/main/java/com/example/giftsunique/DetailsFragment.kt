package com.example.giftsunique

import SingletonSize
import android.content.Intent
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.giftsunique.Extensions.toast
import com.example.giftsunique.Models.ProductOrderModel
import com.example.giftsunique.Models.ProductDisplayModel
import com.example.giftsunique.databinding.FragmentDetailspageBinding
import com.example.giftsunique.rvadapters.SizeAdapter
import com.example.giftsunique.rvadapters.SizeOnClickInterface
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class DetailsFragment : AppCompatActivity(), SizeOnClickInterface {

    private lateinit var binding: FragmentDetailspageBinding
    private lateinit var productDatabaseReference: DatabaseReference
    private lateinit var sizeAdapter: SizeAdapter
    private lateinit var auth: FirebaseAuth

    private val orderDatabaseReference = Firebase.firestore.collection("orders")

    private lateinit var currentUID :  String
    private lateinit var orderImageUrl:String
    private lateinit var orderName:String
    private var orderSize:String?  = null
    private lateinit var orderPrice:String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
            binding = FragmentDetailspageBinding.inflate(layoutInflater)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
            setContentView(binding.root)
            productDatabaseReference = FirebaseDatabase.getInstance().getReference("products")

            auth = FirebaseAuth.getInstance()

            currentUID = auth.currentUser!!.uid
            binding.detailActualToolbar.setNavigationOnClickListener {
                onBackPressed()
            }

            val valueEvent = object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if (snapshot.exists()) {
                        for (dataSnapshot in snapshot.children) {
                            val products = dataSnapshot.getValue(ProductDisplayModel::class.java)
                            var currentItemId = SingletonID.getId()
                            SingletonID.setId(currentItemId)
                            if (products?.id == currentItemId) {
                                Glide
                                    .with(this@DetailsFragment)
                                    .load(products.imageUrl)
                                    .into(binding.ivDetails)

                                orderImageUrl = products.imageUrl!!
                                orderName = products.name!!

                                orderPrice = products.price!!

                                val sizeList = ArrayList<String>()
                                if(products.brand=="Breloc") {
                                    sizeList.add("5x1")
                                    sizeList.add("2,5x3")
                                    sizeList.add("3x4,5")
                                    sizeList.add("5x5")
                                    sizeList.add("4x3")
                                    SingletonSize.setList(sizeList)
                                }else{
                                    if(products.brand=="Glob") {
                                        sizeList.clear()
                                        sizeList.add("5x5")
                                        sizeList.add("6x4")
                                        sizeList.add("5,5x9")
                                        sizeList.add("8x8")
                                        sizeList.add("10x7")
                                    SingletonSize.setList(sizeList)
                                }
                                else{
                                    if(products.brand=="Rama") {
                                        sizeList.clear()
                                        sizeList.add("15x 20")
                                        sizeList.add("20x 30")
                                        sizeList.add("15x 15")
                                        sizeList.add("25x 25")
                                        sizeList.add("10x 15")
                                        SingletonSize.setList(sizeList)
                                    }}}

                                binding.tvDetailsProductPrice.text = "${products.price} lei"
                                binding.tvDetailsProductName.text = "${products.name}"
                                binding.tvDetailsProductDescription.text = products.description

                            }

                            }


                        }


                    }



                override fun onCancelled(error: DatabaseError) {
                    toast(error.message)
                }

            }

            productDatabaseReference.addValueEventListener(valueEvent)
            var sizeList = ArrayList<String>()
            sizeList=SingletonSize.getList()
            SingletonSize.clear()
            sizeAdapter = SizeAdapter(this , sizeList , this)
            binding.rvSelectSize.adapter = sizeAdapter



            binding.btnDetailsAddToCart.setOnClickListener {

                val orderedProduct = ProductOrderModel(currentUID, SingletonID.getId(),orderImageUrl,orderName,orderSize,orderPrice)

                if(orderSize.isNullOrBlank()){
                    toast("Select Size")
                }else{
                    addDataToOrdersDatabase(orderedProduct)
                    val intent = Intent(this, CartFragment::class.java)
                    startActivity(intent)
                }


            }

        }
    override fun onBackPressed() {
        val intent = Intent(this, MainFragment::class.java)
        startActivity(intent)
    }
        private fun addDataToOrdersDatabase(orderedProduct: ProductOrderModel) {

            orderDatabaseReference.add(orderedProduct).addOnCompleteListener{task ->
                if(task.isSuccessful){
                }else{
                    toast(task.exception!!.localizedMessage!!)
                }
            }

        }

        override fun onClickSize(button: Button , position :Int) {
            orderSize = button.text.toString()
            SingletonSize.setSize(orderSize!!)
            toast("Marimea ${button.text} a fost selectata")
        }

    }