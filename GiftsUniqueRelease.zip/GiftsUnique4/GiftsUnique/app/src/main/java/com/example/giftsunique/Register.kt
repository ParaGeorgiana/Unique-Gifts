package com.example.giftsunique

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class Register : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private val emailRegex = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
        setContentView(R.layout.signup_activity)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        val username = findViewById<TextInputLayout>(R.id.usernameRegister)
        val password = findViewById<TextInputLayout>(R.id.passwordRegister)
        val fullName = findViewById<TextInputLayout>(R.id.fullName)
        val phoneNumber = findViewById<TextInputLayout>(R.id.phoneNumber)
        val email = findViewById<TextInputLayout>(R.id.Email)
        val confirmPassword = findViewById<TextInputLayout>(R.id.confirmPassword)
        val saveData = findViewById<Button>(R.id.saveData)
        val spinner = findViewById<Spinner>(R.id.spinner)
        val adapter = ArrayAdapter.createFromResource(
            this, R.array.spinner_items, android.R.layout.simple_spinner_item
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, position: Int, id: Long
            ) {
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }
        saveData.setOnClickListener {
            val sdUsername = username.editText?.text.toString()
            val sdPassword = password.editText?.text.toString()
            val sdFullName = fullName.editText?.text.toString()
            val sdPhoneNumber = phoneNumber.editText?.text.toString()
            val sdEmail = email.editText?.text.toString()
            val sdConfirmPassword = confirmPassword.editText?.text.toString()
            val sdRole = spinner.selectedItem.toString()
            if (sdUsername.isEmpty() || sdEmail.isEmpty() || sdPassword.isEmpty() || sdFullName.isEmpty() || sdPhoneNumber.isEmpty() || sdConfirmPassword.isEmpty()) {
                if (sdUsername.isEmpty()) {
                    username.error = "Intrdu Username-ul"
                }
                if (sdEmail.isEmpty()) {
                    email.error = "Introdu mailul"
                }
                if (sdPassword.isEmpty()) {
                    password.error = "Introdu parola"
                }
                if (sdFullName.isEmpty()) {
                    fullName.error = "Introdu numele complet"
                }
                if (sdPhoneNumber.isEmpty()) {
                    phoneNumber.error = "Introdu numarul de telefon"
                }
                if (sdConfirmPassword.isEmpty()) {
                    confirmPassword.error = "Confirma parola"
                }
                Toast.makeText(this, "Verifica campurile", Toast.LENGTH_SHORT).show()

            } else if (!sdEmail.matches(emailRegex.toRegex())) {
                email.error = "Te rog sa introduci o adresa de mail valida"
                Toast.makeText(this, "Te rog sa introduci o adresa de mail valida", Toast.LENGTH_SHORT)
                    .show()
            } else if (sdPhoneNumber.length != 10) {
                phoneNumber.error = "Numarul de telefon are 10 cifre"
                Toast.makeText(this, "Numarul de telefon are 10 cifre ", Toast.LENGTH_SHORT).show()
            } else if (sdPassword.length < 7) {
                password.error = "Parola trebuie sa aiba mai mult de 7 caractere"
                Toast.makeText(
                    this, "Parola trebuie sa aiba mai mult de 7 caractere", Toast.LENGTH_SHORT
                ).show()
            } else if (sdPassword != sdConfirmPassword) {
                confirmPassword.error = "Parolele nu corespund"
                Toast.makeText(this, "Parolele nu corespund", Toast.LENGTH_SHORT).show()
            } else {
                auth.createUserWithEmailAndPassword(sdEmail, sdPassword)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            val databaseRef =
                                database.reference.child("Users").child(auth.currentUser!!.uid)
                            val user = User(
                                username = sdUsername,
                                password = sdPassword,
                                fullName = sdFullName,
                                phoneNumber = sdPhoneNumber,
                                role = sdRole,
                                uid = auth.currentUser!!.uid
                            )
                            databaseRef.setValue(user).addOnCompleteListener {
                                if (it.isSuccessful) {
                                    val intent = Intent(this, Login::class.java)
                                    startActivity(intent)
                                    Toast.makeText(this, "Te-ai inregistrat cu succes!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(
                                        this, "Something wrong with intent", Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                        } else {
                            Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }
    }
}