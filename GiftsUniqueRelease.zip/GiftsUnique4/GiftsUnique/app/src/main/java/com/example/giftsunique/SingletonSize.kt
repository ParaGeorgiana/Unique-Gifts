object SingletonSize {
    private var size: String = ""
    private val itemList = ArrayList<String>()

    fun setList(items: List<String>) {
        itemList.addAll(items)
    }

    fun getList(): ArrayList<String> {
        return itemList
    }

    fun clear() {
        itemList.clear()
    }
    fun getSize(): String {
        return size
    }

    fun setSize(id: String) {
        this.size = id
    }
}