package com.example.giftsunique

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class GiveOrder : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase
    private lateinit var clientWords: EditText
    private lateinit var back: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
        setContentView(R.layout.order_create)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        back = findViewById(R.id.BackButton)
        back.setOnClickListener {
            val intent = Intent(this, ClientMain::class.java)
            intent.putExtra("fullName", SingletonName.getId())
            startActivity(intent)
        }

        clientWords = findViewById(R.id.clientWords)

        val sendRequest = findViewById<LinearLayout>(R.id.sendRequestLayout)
        sendRequest.setOnClickListener {
            val order = clientWords.text.toString()
            val databaseRef = FirebaseDatabase.getInstance().getReference("Users/")
            val userRef = auth.currentUser?.uid?.let { it1 -> databaseRef.child(it1) }
            userRef?.get()?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val uid = database.reference.push().key
                    val request = Order(
                        clientUID = auth.currentUser?.uid,
                        order = order,
                        accepted = false,
                        active = true,
                        uid = uid
                    )
                    if (uid != null) {
                        database.reference.child("Order").child(uid).setValue(request)
                            .addOnSuccessListener {
                                database.reference.child("Order").child(uid).setValue(request)
                                val intent = Intent(this, ClientMain::class.java)
                                intent.putExtra("fullName", SingletonName.getId())
                                startActivity(intent)
                                Toast.makeText(this, "Cererea a fost trimisa", Toast.LENGTH_SHORT).show()
                            }.addOnFailureListener {
                                Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show()
                            }
                    }
                } else {
                    Log.d(
                        "TAG", task.exception!!.message!!
                    )
                }
            }
        }
    }
}