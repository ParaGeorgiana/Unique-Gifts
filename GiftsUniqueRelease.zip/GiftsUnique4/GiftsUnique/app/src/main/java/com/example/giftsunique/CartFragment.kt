package com.example.giftsunique

import SingletonOrder
import SingletonPrice
import SingletonSize
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.example.giftsunique.Extensions.toast
import com.example.giftsunique.Models.CartModel
import com.example.giftsunique.databinding.FragmentCartpageBinding
import com.example.giftsunique.rvadapters.CartAdapter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObject
import com.google.firebase.ktx.Firebase

class CartFragment : AppCompatActivity(), CartAdapter.OnLongClickRemove {

    private lateinit var binding: FragmentCartpageBinding
    private lateinit var cartList: ArrayList<CartModel>
    private lateinit var auth: FirebaseAuth
    private lateinit var adapter: CartAdapter
    private lateinit var database: FirebaseDatabase
    private var subTotalPrice = 0
    private var totalPrice = 24

    private var orderDatabaseReference = Firebase.firestore.collection("orders")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
        binding = FragmentCartpageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()
        binding.cartActualToolbar.setNavigationOnClickListener {
            onBackPressed()
        }


        val layoutManager = GridLayoutManager(this, 2)


        cartList = ArrayList()

        retrieveCartItems()



        adapter = CartAdapter(this,cartList ,this)
        binding.rvCartItems.adapter = adapter
        binding.rvCartItems.layoutManager = layoutManager
        supportActionBar?.hide()





        binding.btnCartCheckout.setOnClickListener {

            toast(" Ai comandat in valoarea de:  ${totalPrice}\n ")

            val order = SingletonOrder.getString()
            SingletonPrice.setString(binding.tvLastTotalPrice.text.toString())
            val databaseRef = FirebaseDatabase.getInstance().getReference("Users/")
            val userRef = auth.currentUser?.uid?.let { it1 -> databaseRef.child(it1) }
            userRef?.get()?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val uid = database.reference.push().key
                    val request = Order(
                        clientUID = auth.currentUser?.uid,
                        order = order,
                        accepted = false,
                        active = true,
                        uid = uid,
                        size=SingletonSize.getSize(),
                        price = binding.tvLastTotalPrice.text.toString()


                    )
                    if (uid != null) {
                        database.reference.child("Order").child(uid).setValue(request)
                            .addOnSuccessListener {
                                database.reference.child("Order").child(uid).setValue(request)
                                cartList.clear()
                                binding.tvLastSubTotalprice.text ="0"
                                binding.tvLastSubTotalItems.text="SubTotal Produse(0)"
                                binding.tvDeliveryprice.text="24"
                                binding.tvLastTotalPrice.text ="0"
                                SingletonOrder.clear()
                            }.addOnFailureListener {
                                toast("Something wrong")
                            }
                    }
                } else {
                    Log.d(
                        "TAG", task.exception!!.message!!
                    )
                }
            }
            adapter.notifyDataSetChanged()
        }


    }


    override fun onBackPressed() {
        val intent = Intent(this, MainFragment::class.java)
        startActivity(intent)
    }

    @SuppressLint("SuspiciousIndentation")
    private fun retrieveCartItems() {

        orderDatabaseReference
            .whereEqualTo("uid",auth.currentUser!!.uid)
            .get()
            .addOnSuccessListener { querySnapshot ->
                for (item in querySnapshot) {
                    val cartProduct = item.toObject<CartModel>()


                        cartList.add(cartProduct)
                        subTotalPrice += cartProduct.price!!.toInt()
                        totalPrice += cartProduct.price!!.toInt()
                        binding.tvDeliveryprice.text="24"
                        binding.tvLastSubTotalprice.text = subTotalPrice.toString()
                        binding.tvLastTotalPrice.text = totalPrice.toString()
                        binding.tvLastSubTotalItems.text = "SubTotal Produse(${cartList.size})"
                        adapter.notifyDataSetChanged()


                }

            }
            .addOnFailureListener{
                toast(it.localizedMessage!!)
            }


    }

    override fun onLongRemove(item: CartModel, position: Int) {
        if (position >= 0 && position < cartList.size) {
            val cartItem = cartList[position]
            orderDatabaseReference
                .whereEqualTo("uid", cartItem.uid)
                .whereEqualTo("pid", cartItem.pid)
                .whereEqualTo("size", cartItem.size)
                .get()
                .addOnSuccessListener { querySnapshot ->
                    for (item in querySnapshot) {
                        orderDatabaseReference.document(item.id).delete()
                    }
                    cartList.removeAt(position)
                    SingletonOrder.clear()
                    binding.tvDeliveryprice.text = "24"
                    binding.tvLastSubTotalprice.text = "0"
                    binding.tvLastTotalPrice.text = "0"
                    binding.tvLastSubTotalItems.text = "SubTotal Produse(0)"
                    adapter.notifyItemRemoved(position)
                    toast("Produsul a fost sters cu succes")

                }
                .addOnFailureListener {
                    toast("Eroare la stergere")
                }
        }
    }




}