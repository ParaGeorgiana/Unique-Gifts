object SingletonPrice {
    private var price: String = "" // ID variable

    fun getString(): String {
        return price
    }

    fun setString(id: String) {
        this.price = id
    }
}