package com.example.giftsunique
import SingletonName
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import androidx.navigation.Navigation
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.giftsunique.MainFragmentDirections
import com.example.giftsunique.Models.LikeModel
import com.example.giftsunique.Models.ProductDisplayModel
import com.example.giftsunique.databinding.FragmentMainpageBinding
import com.example.giftsunique.rvadapters.CategoryOnClickInterface
import com.example.giftsunique.rvadapters.LikeOnClickInterface
import com.example.giftsunique.rvadapters.MainCategoryAdapter
import com.example.giftsunique.rvadapters.ProductOnClickInterface
import com.example.giftsunique.rvadapters.ProductDisplayAdapter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainFragment : AppCompatActivity(), CategoryOnClickInterface, ProductOnClickInterface,
    LikeOnClickInterface {

    private lateinit var binding: FragmentMainpageBinding
    private lateinit var databaseReference: DatabaseReference
    private lateinit var productList: ArrayList<ProductDisplayModel>
    private lateinit var categoryList: ArrayList<String>
    private lateinit var productsAdapter: ProductDisplayAdapter
    private lateinit var categoryAdapter: MainCategoryAdapter
    private lateinit var auth: FirebaseAuth
    private var likeDBRef = Firebase.firestore.collection("LikedProducts")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
        binding = FragmentMainpageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        categoryList = ArrayList()
        productList = ArrayList()
        databaseReference = FirebaseDatabase.getInstance().getReference("products")
        auth = FirebaseAuth.getInstance()
        categoryList.add("Trending")
        binding.rvMainCategories.setHasFixedSize(true)
        val categoryLayoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        binding.rvMainCategories.layoutManager = categoryLayoutManager
        categoryAdapter = MainCategoryAdapter(categoryList, this)
        binding.rvMainCategories.adapter = categoryAdapter
        setCategoryList()

        val productLayoutManager = GridLayoutManager(this, 2)
        productsAdapter = ProductDisplayAdapter(this, productList, this, this)
        binding.rvMainProductsList.layoutManager = productLayoutManager
        binding.rvMainProductsList.adapter = productsAdapter
        setProductsData()

        binding.bnvMain.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.mainFragment -> {
                   val intent = Intent(this, MainFragment::class.java)
                    startActivity(intent)
                    true
                }
                R.id.likeFragment -> {
                   val intent = Intent(this, LikeFragment::class.java)
                    startActivity(intent)
                    true
                }
                R.id.cartFragment -> {

                   val intent = Intent(this, CartFragment::class.java)
                    startActivity(intent)

                    true
                }
                R.id.profileFragment -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }
    }
    override fun onBackPressed() {
        val intent = Intent(this, ClientMain::class.java)
        intent.putExtra("fullName", SingletonName.getId())
        startActivity(intent)
    }
    private fun setCategoryList() {
        val valueEvent = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                categoryList.clear()
                categoryList.add("Trending")

                if (snapshot.exists()) {
                    for (dataSnapshot in snapshot.children) {
                        val products = dataSnapshot.getValue(ProductDisplayModel::class.java)
                        val brand = products?.brand ?: ""
                        if (!categoryList.contains(brand)) {
                            categoryList.add(brand)
                        }
                    }
                    categoryAdapter.notifyDataSetChanged()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainFragment, "$error", Toast.LENGTH_SHORT).show()
            }
        }

        databaseReference.addValueEventListener(valueEvent)
    }

    private fun setProductsData() {
        val valueEvent = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                productList.clear()

                if (snapshot.exists()) {
                    for (dataSnapshot in snapshot.children) {
                        val products = dataSnapshot.getValue(ProductDisplayModel::class.java)
                        productList.add(products!!)
                    }
                    productsAdapter.notifyDataSetChanged()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainFragment, "$error", Toast.LENGTH_SHORT).show()
            }
        }

        databaseReference.addValueEventListener(valueEvent)
    }

    override fun onClickCategory(button: Button) {
        binding.tvMainCategories.text = button.text

        val valueEvent = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                productList.clear()

                if (snapshot.exists()) {
                    for (dataSnapshot in snapshot.children) {
                        val products = dataSnapshot.getValue(ProductDisplayModel::class.java)

                        if (products!!.brand == button.text) {
                            productList.add(products)
                        }

                        if (button.text == "Trending") {
                            productList.add(products)
                        }
                    }

                    productsAdapter.notifyDataSetChanged()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MainFragment, "$error", Toast.LENGTH_SHORT).show()
            }
        }

        databaseReference.addValueEventListener(valueEvent)
    }

    override fun onClickProduct(item: ProductDisplayModel) {

        val intent = Intent(this, DetailsFragment::class.java)
        startActivity(intent)

    }

    override fun onClickLike(item: ProductDisplayModel) {
        likeDBRef
            .add(LikeModel(item.id , auth.currentUser!!.uid , item.brand , item.description , item.imageUrl , item.name ,item.price))
            .addOnSuccessListener {
                Toast.makeText(this@MainFragment, "Adaugat in lista de favorite", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this@MainFragment, "Eroare la adaugare", Toast.LENGTH_SHORT).show()
            }
    }
}
