package com.example.giftsunique.Models

data class ProductOrderModel(
    val uid : String? = null ,
    val pid : String? = null ,
    val imageUrl: String? = null ,
    val name: String? = null ,
    val size: String? = null ,
    val price: String? = null

)
