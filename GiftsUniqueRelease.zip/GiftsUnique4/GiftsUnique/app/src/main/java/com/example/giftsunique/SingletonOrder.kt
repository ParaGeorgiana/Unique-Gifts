object SingletonOrder {
    private val stringBuilder = StringBuilder()

    fun addString(string: String) {
        if (stringBuilder.isNotEmpty()) {
            stringBuilder.append(" ")
        }
        stringBuilder.append(string)
    }

    fun getString(): String {
        return stringBuilder.toString()
    }

    fun clear() {
        stringBuilder.clear()
    }
}