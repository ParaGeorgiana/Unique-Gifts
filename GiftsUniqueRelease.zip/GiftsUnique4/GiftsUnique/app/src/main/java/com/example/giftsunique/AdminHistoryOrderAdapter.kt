package com.example.giftsunique

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AdminHistoryOrderAdapter(val context: Context, private val orderList: ArrayList<Order>) :
    RecyclerView.Adapter<AdminHistoryOrderAdapter.UserViewHolder>() {

    private lateinit var Dialog: Dialog
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view: View = LayoutInflater.from(context).inflate(R.layout.list_element, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val order = orderList[position]
        val databaseRef = FirebaseDatabase.getInstance().getReference("Users/")
        order.clientUID?.let {
            databaseRef.child(it).addValueEventListener(object : ValueEventListener {
                @SuppressLint("SetTextI18n")
                override fun onDataChange(snapshot: DataSnapshot) {
                    val fullName = snapshot.child("fullName").getValue(String::class.java)
                    val phoneNumber = snapshot.child("phoneNumber").getValue(String::class.java)
                    holder.textName.text = fullName + " - " + order.preparetime
                    holder.itemView.setOnClickListener {
                        Dialog = Dialog(context)
                        Dialog.setContentView(R.layout.pop_out_orders_history)
                        Dialog.setTitle("Pop-up Window")
                        Dialog.findViewById<TextView>(R.id.fullName).text = "Nume: " + fullName
                        Dialog.findViewById<TextView>(R.id.produs).text = order.order.toString()
                        Dialog.findViewById<TextView>(R.id.preparetime).text = order.preparetime
                        Dialog.findViewById<TextView>(R.id.phoneNumber).text = "Numar de telefon: " + phoneNumber
                        Dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                        Dialog.window!!.setLayout(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        )
                        Dialog.show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                }
            })
        }
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textName: TextView = itemView.findViewById(R.id.txt_name)
    }
}