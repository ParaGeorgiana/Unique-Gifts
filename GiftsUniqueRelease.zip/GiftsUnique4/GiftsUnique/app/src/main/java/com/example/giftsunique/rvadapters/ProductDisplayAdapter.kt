package com.example.giftsunique.rvadapters

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

import com.example.giftsunique.Models.ProductDisplayModel
import com.example.giftsunique.databinding.ProductdisplaymainItemBinding

class ProductDisplayAdapter(
   private val context:Context ,
   private val list: List<ProductDisplayModel>,
   private val productClickInterface: ProductOnClickInterface,
   private val likeClickInterface: LikeOnClickInterface,
    ) : RecyclerView.Adapter<ProductDisplayAdapter.ViewHolder>() {
    private var currentItemID: String = ""

    inner class ViewHolder(val binding: ProductdisplaymainItemBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(ProductdisplaymainItemBinding.inflate(LayoutInflater.from(parent.context),
            parent,
            false))
    }

    @SuppressLint("SuspiciousIndentation")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val currentItem = list[position]
         var currentItemID:String
        holder.binding.tvNameProductDisplayItem.text = "${currentItem.name}"
        holder.binding.tvPriceProductDisplayItem.text = "${currentItem.price} lei"


            Glide
                .with(context)
                .load(currentItem.imageUrl)
                .into(holder.binding.ivProductDisplayItem)


            holder.itemView.setOnClickListener {
            productClickInterface.onClickProduct(list[position])
                currentItemID= currentItem.id.toString()
                SingletonID.setId(currentItemID)


        }

        holder.binding.btnLike.setOnClickListener {
            if(holder.binding.btnLike.isChecked){
                holder.binding.btnLike.backgroundTintList = ColorStateList.valueOf(Color.RED)
                likeClickInterface.onClickLike(currentItem)
            }
            else{
                holder.binding.btnLike.backgroundTintList = ColorStateList.valueOf(Color.WHITE)
            }

        }

    }

    override fun getItemCount(): Int {
        return list.size
    }


}

interface ProductOnClickInterface {
    fun onClickProduct(item: ProductDisplayModel)

}

interface LikeOnClickInterface{
    fun onClickLike(item :ProductDisplayModel)
}