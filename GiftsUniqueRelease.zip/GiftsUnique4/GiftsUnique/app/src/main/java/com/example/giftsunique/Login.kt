package com.example.giftsunique
import SingletonName
import SingletonPhone
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import android.util.Log
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import com.google.android.material.textfield.TextInputEditText

class Login : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private val emailRegex = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"
    @SuppressLint("MissingInflatedId", "SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        supportActionBar?.hide()
        setContentView(R.layout.login_activity)
        auth = FirebaseAuth.getInstance()
        val logInEmail = findViewById<TextInputLayout>(R.id.emailLogIn)
        val logInPassword = findViewById<TextInputEditText>(R.id.passwordLogIn)
        val loginButton = findViewById<Button>(R.id.loginButton)

        loginButton.setOnClickListener {
            val email = logInEmail.editText?.text.toString()
            val password = logInPassword.text.toString()
            if (email.isEmpty() || password.isEmpty()) {
                if (email.isEmpty()) {
                    logInEmail.error = "Introdu username-ul"
                }
                if (password.isEmpty()) {
                    logInPassword.error = "Introdu parola"
                }
                Toast.makeText(this, "Intrdu credentiale valabile", Toast.LENGTH_SHORT).show()
            } else if (!email.matches(emailRegex.toRegex())) {
                logInEmail.error = "Introdu o adresa valabila"
                Toast.makeText(this, "Introdu o adresa valabila", Toast.LENGTH_SHORT)
                    .show()
            } else if (password.length < 7) {
                logInPassword.error = "Parola trebuia sa aiba mai mult de 7 caractere"
                Toast.makeText(
                    this, "Parola trebuia sa aiba mai mult de 7 caractere", Toast.LENGTH_SHORT
                ).show()
            } else {
                auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { it1 ->
                    if (it1.isSuccessful) {
                        val uid = FirebaseAuth.getInstance().currentUser!!.uid
                        val databaseRef = FirebaseDatabase.getInstance().getReference("Users/")
                        val userRef = databaseRef.child(uid)
                        userRef.get().addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val snapshot = task.result
                                val role = snapshot.child("role").getValue(String::class.java)
                                val fullName =
                                    snapshot.child("fullName").getValue(String::class.java)
                                    SingletonName.setId(fullName!!)
                                val phoneNumber =
                                    snapshot.child("phoneNumber").getValue(String::class.java)
                                SingletonPhone.setId(phoneNumber!!)
                                if (role.equals("Client")) {
                                    val intent = Intent(this, ClientMain::class.java)
                                    intent.putExtra("fullName", fullName)
                                    intent.putExtra("phoneNumber", phoneNumber)
                                    startActivity(intent)
                                    Toast.makeText(this, "Te-ai logat in rolul de Client", Toast.LENGTH_SHORT).show()
                                } else {
                                    val intent = Intent(this, AdminMain::class.java)
                                    intent.putExtra("fullName", fullName)
                                    intent.putExtra("phoneNumber", phoneNumber)
                                    startActivity(intent)
                                    Toast.makeText(this, "Te-ai logat in rolul de Admin ", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                Log.d(
                                    "TAG", task.exception!!.message!!
                                )
                            }


                        }
                    } else {
                        Toast.makeText(this, "Something wrong", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    }
}
