package com.example.giftsunique

import SingletonPhone
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class AdminOrderAdapter(val context: Context, private val orderList: ArrayList<Order>) :
    RecyclerView.Adapter<AdminOrderAdapter.UserViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
        val view: View = LayoutInflater.from(context).inflate(R.layout.list_element, parent, false)
        return UserViewHolder(view)
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val order = orderList[position]
        val databaseRef = FirebaseDatabase.getInstance().getReference("Users/")
        order.clientUID?.let {
            databaseRef.child(it).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val fullName = snapshot.child("fullName").getValue(String::class.java)
                    holder.textName.text = fullName + " - " + order.preparetime
                    holder.itemView.setOnClickListener {
                        val intent = Intent(context, AdminOrderView::class.java)
                        intent.putExtra("clientUID", order.clientUID)
                        intent.putExtra("preparetime", order.preparetime)
                        intent.putExtra("adminUID", FirebaseAuth.getInstance().currentUser?.uid)
                        intent.putExtra("orderStatus", order.orderStatus)
                        intent.putExtra("order", order.order)
                        intent.putExtra("orderUID", order.uid)
                        intent.putExtra("fullName", fullName)
                        intent.putExtra("phoneNumber",SingletonPhone.getId())

                        context.startActivity(intent)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Do nothing
                }
            })
        }
    }

    override fun getItemCount(): Int {
        return orderList.size
    }

    class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val textName: TextView = itemView.findViewById(R.id.txt_name)
    }
}