package com.example.giftsunique
data class User(
    var uid: String? = null,
    var username: String? = null,
    var password: String? = null,
    var fullName: String? = null,
    var phoneNumber: String? = null,
    var role: String? = null
)