package com.example.giftsunique.Models

data class ProductDisplayModel(

    var brand: String? = null,
    val description: String? = null,
    val id:String? = null,
    var imageUrl: String? = null,
    val name: String? = null,
    val price: String? = null,

    )